package com.example.caixaeletronico

var din = 0

fun main(){
    println("       -Caixa Eletronico-       ")
    while (true) {
        println("================================")
        println("[1] Depositar")
        println("[2] sacar")
        println("[3] Consultar")
        println("[4] Sair")
        println("================================")
        print("Input: ")
        var entrada = readLine()?.toIntOrNull()

        if (entrada == 1) {
            depositar()
        } else if (entrada == 2){
            sacar()
        }else if (entrada == 3) {
            consultar()
        } else if (entrada == 4){
            break
        } else {
            println("[ERRO 404: VALOR NÃO ENCONTRADO]")
        }
    }
}

fun consultar(){
    println("Deposito: R$$din")
}

fun depositar(){
    print("Depositar: R$")
    val deposito: Int = readLine()!!.toInt()
    din += deposito.toInt()
    println("Tarefa concluida :)")
}

fun sacar(){
    print("Sacar: R$")
    var saque: Int = readLine()!!.toInt()
    if (din >= saque) {
        din -= saque
        println("Tarefa concluida :)")
    } else {
        println("Saldo insuficiente :(")
    }
}
